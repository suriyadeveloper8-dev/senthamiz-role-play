SENTHAMIZ ROLE PLAY — BROWSER DEMO v0.3

This is a static browser-playable preview. It does not need Node.js or an APK.
It is single-player only; multiplayer needs a separately hosted server.

To publish it so you can play by URL:
1. Upload index.html to a static web host such as GitHub Pages or Netlify.
2. Open the published HTTPS URL in Chrome on your phone.
3. Tap PLAY, then use the on-screen arrows, RUN, CAR, and touch-drag camera.

Important: This chat cannot publish a public website URL directly. The HTML file must be uploaded to a hosting service once. The Three.js library is loaded from a CDN, so the browser needs internet access.
